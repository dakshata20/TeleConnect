import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to the Home Page!</h2>
      <p>You have successfully logged in.</p>
    </div>
  );
};

export default Home;
